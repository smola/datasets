# ShareX

[![Build status](https://img.shields.io/appveyor/ci/ShareX/sharex.svg?label=Build&maxAge=60)](https://ci.appveyor.com/project/ShareX/sharex)
[![License](https://img.shields.io/github/license/ShareX/ShareX.svg?label=License&maxAge=86400)](./LICENSE.txt)
[![Release](https://img.shields.io/github/release/ShareX/ShareX.svg?label=Release&maxAge=60)](https://github.com/ShareX/ShareX/releases/latest)
[![Downloads](https://img.shields.io/github/downloads/ShareX/ShareX/latest/total.svg?label=Downloads&maxAge=60)](https://getsharex.com/downloads/)
[![Discord](https://discordapp.com/api/guilds/194170124859736065/widget.png)](https://discord.gg/E4R3Qa9)

[![Screenshot](https://getsharex.com/img/ShareX_Animation.gif)](https://getsharex.com)

### Check [getsharex.com](https://getsharex.com) for more info.
